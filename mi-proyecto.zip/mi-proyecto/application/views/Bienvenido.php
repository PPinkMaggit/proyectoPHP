<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Bienvenido</title>

	<style type="text/css">
	</style>
</head>
<body>

    <h1>Hola Bienvenido!</h1>

</body>
</html>
