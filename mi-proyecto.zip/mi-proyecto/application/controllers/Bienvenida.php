<?php 

class Bienvenido extends CI_Controller
{
    public function index()
	{
		$this->load->view('bienvenido');
	}
}