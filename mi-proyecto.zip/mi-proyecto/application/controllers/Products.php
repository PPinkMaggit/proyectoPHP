<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {	
	//Para manejar la tabla necesitamos 7 metodos
	//index -> muestra la lista de productos -> vista 
	public function __construct()
	{
		parent:: __construct();
		$this->load->model('product_model');
	}
	
	
	public function index() 
	{
		$product = $this->product_model->obtener_productos();

		$arreglo = [
				'content' => 'Por fin lacoincgha tuya',
				'products' => $products
		];

		$this->load->view('products/index', $arreglo);
		//echo "Ruta products/index";
	}


	// show ->	muestra un solo producto (Precisa del id) -> Devuelve vista
	public function show($id)
	{
		echo "Ruta products/show/$id";
	}
	//create -> carga nuevos productos (form) -> devuelve vista
	public function create()
	{
		echo "Ruta products/create";
	}
	// store -> pocesa los datos del nuevo producto -> es un proceso
	public function store()
	{
		//
	}
	// edit -> entrada de datos para actualizar un producto existente -> es un form y devuelve una vista
	public function edit($id)
	{
		echo "Ruta products/edit/$id";
	} 
	// update -> procesa los nuevos datos del producto editado -> PROCESO 
	public function update($id,$newDate)
	{
		//
	}
	public function delete($id)
	{
		//
	}
	//dELETE -> borra un producto -> proceso 
}
