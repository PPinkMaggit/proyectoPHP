<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function obtener_productos()
    {
        $query = $this->db->get('product');
        return $query->result();
    }
}